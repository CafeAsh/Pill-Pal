from picamera2 import Picamera2
from models.common import DetectMultiBackend
from utils.general import (non_max_suppression, scale_boxes, check_img_size, cv2)
from utils.torch_utils import select_device
from utils.augmentations import letterbox
from ultralytics.utils.plotting import Annotator, colors

import torch
import numpy as np
import time

# Configs
weights_path = 'best.pt'
imgsz = (640, 640)
conf_thres = 0.25
iou_thres = 0.45

# Initialize PiCamera2
picam2 = Picamera2()
picam2.preview_configuration.main.size = (640, 480)
picam2.preview_configuration.main.format = "RGB888"
picam2.configure("preview")
picam2.start()

# Set device
device = select_device('')
model = DetectMultiBackend(weights_path, device=device)
stride, names, pt = model.stride, model.names, model.pt
imgsz = check_img_size(imgsz, s=stride)
model.warmup(imgsz=(1, 3, *imgsz))

# Detection loop
while True:
    frame = picam2.capture_array()
    img = letterbox(frame, imgsz, stride=stride, auto=pt)[0]
    img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
    img = np.ascontiguousarray(img)

    im = torch.from_numpy(img).to(model.device)
    im = im.half() if model.fp16 else im.float()
    im /= 255
    im = im[None]  # add batch dim

    pred = model(im, augment=False, visualize=False)
    pred = non_max_suppression(pred, conf_thres, iou_thres)

    im0 = frame.copy()
    annotator = Annotator(im0, line_width=2, example=str(names))

    for det in pred:
        if len(det):
            det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], im0.shape).round()
            for *xyxy, conf, cls in reversed(det):
                label = f'{names[int(cls)]} {conf:.2f}'
                annotator.box_label(xyxy, label, color=colors(int(cls), True))

    cv2.imshow("PiCam YOLOv5", annotator.result())
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cv2.destroyAllWindows()